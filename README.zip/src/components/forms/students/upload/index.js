
export { default as UploadAvatar } from './UploadAvatar';
